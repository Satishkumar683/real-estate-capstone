
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "198.105.121.200",
                port: parseInt(6462)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "zdwiwztl",
                    password: "hyd9wqukuc41"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    