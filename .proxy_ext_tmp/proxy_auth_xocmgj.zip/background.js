
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "191.96.254.138",
                port: parseInt(6185)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "zdwiwztl",
                    password: "hyd9wqukuc41"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    