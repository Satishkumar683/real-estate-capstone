
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "45.38.107.97",
                port: parseInt(6014)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "zdwiwztl",
                    password: "hyd9wqukuc41"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    