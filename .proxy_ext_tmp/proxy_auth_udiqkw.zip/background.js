
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "31.56.127.193",
                port: parseInt(7684)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "zdwiwztl",
                    password: "hyd9wqukuc41"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    